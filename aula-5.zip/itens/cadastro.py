def cliente():
  print('Cadastro de cliente')
