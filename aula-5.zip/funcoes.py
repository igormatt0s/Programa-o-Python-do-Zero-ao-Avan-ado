def somar():
  print('Esta função vai somar valores')


def multi():
  print('Esta função vai multiplicar valores')


def encontrar_index(encontrar, item):
  for i, valor in enumerate(encontrar):
    if valor == item:
      return i
  return -1
