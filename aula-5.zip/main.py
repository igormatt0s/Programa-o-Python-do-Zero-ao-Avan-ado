# Modulos

# importa tudo que estiver em funcoes
import funcoes
# importa apenas a função multi
from funcoes import encontrar_index, multi
from itens.cadastro import cliente

funcoes.somar()
multi()
cliente()

lista1 = ['a', 'b', 'c', 'd', 'e']

var = encontrar_index(lista1, 'b')
print(var)
